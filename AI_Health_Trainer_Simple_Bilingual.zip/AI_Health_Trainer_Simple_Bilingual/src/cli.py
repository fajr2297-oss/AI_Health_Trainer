"""cli.py
Simple command-line interface using argparse for train / predict / evaluate.
"""
import argparse
from .train import train
from .predict import predict_from_saved
from .evaluate import evaluate

def main():
    parser = argparse.ArgumentParser(prog='ai_health_trainer', description='AI Health Trainer CLI')
    sub = parser.add_subparsers(dest='cmd')

    p_train = sub.add_parser('train')
    p_train.add_argument('--epochs', type=int, default=10)
    p_train.add_argument('--batch-size', type=int, default=32)

    p_predict = sub.add_parser('predict')
    p_predict.add_argument('--sample-size', type=int, default=5)

    p_eval = sub.add_parser('evaluate')

    args = parser.parse_args()
    if args.cmd == 'train':
        train(epochs=args.epochs, batch_size=args.batch_size)
    elif args.cmd == 'predict':
        predict_from_saved(sample_size=args.sample_size)
    elif args.cmd == 'evaluate':
        evaluate()
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
