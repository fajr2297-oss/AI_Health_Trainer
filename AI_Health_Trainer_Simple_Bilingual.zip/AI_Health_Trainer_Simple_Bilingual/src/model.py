"""model.py
Simple Keras model: small, fast, and suitable for demonstration.
"""
from tensorflow import keras
from tensorflow.keras import layers

def build_simple_model(input_shape):
    model = keras.Sequential([
        layers.InputLayer(input_shape=(input_shape,)),
        layers.Dense(32, activation='relu'),
        layers.Dense(16, activation='relu'),
        layers.Dense(1, activation='sigmoid')  # binary classification
    ])
    model.compile(optimizer='adam',
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    return model
