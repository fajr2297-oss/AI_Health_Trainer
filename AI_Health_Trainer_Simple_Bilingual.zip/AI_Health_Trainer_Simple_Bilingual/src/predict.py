"""predict.py
Load saved model and scaler, run predictions on random samples or a provided CSV.
"""
import os
import numpy as np
import joblib
from tensorflow import keras

def predict_from_saved(sample_size=5):
    if not os.path.exists('artifacts/model.keras'):
        raise FileNotFoundError('Model not found. Train the model first.')
    model = keras.models.load_model('artifacts/model.keras')
    scaler = joblib.load('artifacts/scaler.pkl')
    # load default dataset to sample from
    from sklearn.datasets import load_breast_cancer
    data = load_breast_cancer()
    X = data.data
    # scale
    X_scaled = scaler.transform(X)
    idx = np.random.choice(range(X_scaled.shape[0]), size=sample_size, replace=False)
    samples = X_scaled[idx]
    preds = model.predict(samples).ravel()
    for i, p in enumerate(preds, 1):
        label = 'malignant' if p >= 0.5 else 'benign'
        print(f"Sample {i}: probability={p:.4f} -> {label}")
    return preds

if __name__ == '__main__':
    predict_from_saved()
