"""data_prep.py
Simple data loading and preprocessing.
Supports sklearn breast cancer dataset or a user CSV.
"""
import pandas as pd
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib

def load_default_dataset(test_size=0.2, random_state=42):
    data = load_breast_cancer()
    X = pd.DataFrame(data.data, columns=data.feature_names)
    y = pd.Series(data.target)
    return prepare_split(X, y, test_size, random_state)

def load_csv(path, target_column, test_size=0.2, random_state=42):
    df = pd.read_csv(path)
    if target_column not in df.columns:
        raise ValueError(f"Target column '{target_column}' not found in CSV")
    X = df.drop(columns=[target_column])
    y = df[target_column]
    return prepare_split(X, y, test_size, random_state)

def prepare_split(X, y, test_size=0.2, random_state=42):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    # Save scaler for later use
    joblib.dump(scaler, 'artifacts/scaler.pkl')
    return X_train_scaled, X_test_scaled, y_train.values, y_test.values
