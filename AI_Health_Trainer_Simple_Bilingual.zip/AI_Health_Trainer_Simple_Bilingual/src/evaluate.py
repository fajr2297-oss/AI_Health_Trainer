"""evaluate.py
Evaluate saved model on the test split.
"""
import os
import joblib
from tensorflow import keras
from .data_prep import load_default_dataset
import numpy as np

def evaluate():
    if not os.path.exists('artifacts/model.keras'):
        raise FileNotFoundError('Model not found. Train the model first.')
    model = keras.models.load_model('artifacts/model.keras')
    # scaler is already saved; data_prep will save it again when loading but here we just load test split
    X_train, X_test, y_train, y_test = load_default_dataset()
    loss, acc = model.evaluate(X_test, y_test, verbose=0)
    print(f"Test loss: {loss:.4f}, Test accuracy: {acc:.4f}")
    return loss, acc

if __name__ == '__main__':
    evaluate()
