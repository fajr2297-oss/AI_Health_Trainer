"""train.py
Training routine for the simple model.
Saves model to artifacts/model.keras and metadata to artifacts/metadata.json
"""
import json
import datetime
import os
from tensorflow import keras
from .data_prep import load_default_dataset
from .model import build_simple_model

def train(epochs=10, batch_size=32):
    X_train, X_test, y_train, y_test = load_default_dataset()
    model = build_simple_model(X_train.shape[1])
    history = model.fit(X_train, y_train, validation_data=(X_test, y_test),
                        epochs=epochs, batch_size=batch_size, verbose=2)
    # Save model
    os.makedirs('artifacts', exist_ok=True)
    model.save('artifacts/model.keras')
    # Save metadata
    metadata = {
        'trained_at': datetime.datetime.utcnow().isoformat() + 'Z',
        'epochs': epochs,
        'batch_size': batch_size,
        'final_train_loss': float(history.history['loss'][-1]),
        'final_train_accuracy': float(history.history['accuracy'][-1]),
        'final_val_loss': float(history.history['val_loss'][-1]),
        'final_val_accuracy': float(history.history['val_accuracy'][-1]),
    }
    with open('artifacts/metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    print('Training completed. Model and metadata saved to artifacts/')
    return metadata

if __name__ == '__main__':
    # simple CLI fallback
    train()
