
# AI Health Trainer — Simple (Bilingual English / العربية)

**A compact educational project** that trains a small neural network to predict breast cancer (benign/malignant).

## Overview — ملخص
- This repository contains a minimal yet professional structure for an AI demo.
- يحوي المشروع بنية بسيطة ومنظمة لعرض مشروع تصنيف طبي تعليمي.

## Quickstart — بداية سريعة
1. Create a virtualenv and install requirements:
   ```bash
   pip install -r requirements.txt
   ```
2. Train the model (default uses sklearn breast cancer dataset):
   ```bash
   python -m src.cli train --epochs 10 --batch-size 32
   ```
   أو بالعربية:
   ```
   python -m src.cli train --epochs 10 --batch-size 32
   ```
3. Predict (after training):
   ```bash
   python -m src.cli predict --sample-size 5
   ```

## Structure — هيكل المشروع
```
AI_Health_Trainer_Simple_Bilingual/
├── src/                # source code
├── artifacts/          # saved model, scaler, metadata after training
├── config.json         # basic settings
├── requirements.txt
└── README.md
```

## Files — الملفات المهمة
- `src/data_prep.py` — load and preprocess data / تحميل وتحضير البيانات
- `src/model.py` — Keras model definition / تعريف نموذج Keras
- `src/train.py` — training routine and saving artifacts / روتين التدريب وحفظ النواتج
- `src/predict.py` — load model and run quick predictions / تحميل النموذج وتشغيل التنبؤات
- `src/cli.py` — command-line interface / واجهة سطر الأوامر

## Notes — ملاحظات
- The model is intentionally simple for teaching/demo purposes.
- يمكن تحميل CSV خاص بك عبر تعديل `src/data_prep.py` أو إضافة وظيفة تحميل CSV جديدة.
- If you want, I can extend this project with logging, evaluation scripts, or a small Streamlit app.
