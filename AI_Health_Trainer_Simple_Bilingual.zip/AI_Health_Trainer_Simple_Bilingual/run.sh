#!/usr/bin/env bash
# Simple helper: create venv, install, and show help
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
echo "To train: python -m src.cli train --epochs 10 --batch-size 32"
